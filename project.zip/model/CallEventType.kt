package com.me.callping.model

enum class CallEventType {
    INCOMING_CALL
}
