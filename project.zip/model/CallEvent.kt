package com.me.callping.model

data class CallEvent (
    val type: CallEventType,
    val timestamp: Long
)
