package com.me.callping.model

data class PairedDevice (
    val id: String,
    val name: String
)
